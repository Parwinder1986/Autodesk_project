#!/usr/bin/bash

export FLASK_APP=hello.py
export FLASK_ENV=development
flask run
