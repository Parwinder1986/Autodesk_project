from flask import Flask, request
import time

app = Flask(__name__)


@app.route('/')
def hello():
    accept_list = request.headers.getlist('accept')
    ts = time.time()
    app.logger.debug('%s %s', ts, request.url)
    print(accept_list)
    if "application/json" in accept_list:
        return {"message": "Hello, World"}
    return "<p>Hello, World</p>"

if __name__ == '__main__':
    app.debug = True
    host = '127.0.0.1'
    port = 5000
    app.run(host=host, port=port, use_reloader=False)