import unittest

from hello import app

class TestFlaskApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()


    def test_hello_world_accept_json(self):
        res = self.app.get('/', headers={'ACCEPT': 'application/json'})
        self.assertEqual(res.status_code, 200)
        str_response = str(res.data)
        self.assertIn('{"message":"Hello, World"}', str_response)

    def test_hello_world_no_headers(self):
        res = self.app.get('/')
        self.assertEqual(res.status_code, 200)
        str_response = str(res.data)
        self.assertIn("<p>Hello, World</p>", str_response)

if __name__ == '__main__':
    unittest.main()
