1) Please download and install python and pip

➜ ✗ python -V
Python 3.9.6
➜  ✗ pip -V
pip 21.1.3 from /usr/local/lib/python3.9/site-packages/pip (python 3.9)


2) install app
   `./install-app.sh`

3) start app

`./start-app.sh`

4) how to code on the local. 

open another terminal , u can use postman also

    a) accept header
        `curl -s --header "accept: application/json" http://localhost:5000`
    
    b) not accept header
    
        `curl -s http://localhost:5000`

`
5) Run the two test cases.

python -m unittest test_app


